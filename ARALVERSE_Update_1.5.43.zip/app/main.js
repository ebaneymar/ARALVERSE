const {app, BrowserWindow, ipcMain, shell} = require("electron");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const crypto = require("crypto");
const os = require("os");
const {spawnSync} = require("child_process");

app.disableHardwareAcceleration();
// Classroom video intros should play with their original audio immediately.
app.commandLine.appendSwitch("autoplay-policy","no-user-gesture-required");

const APP_VERSION = "1.5.43";

const installRoot = () => path.dirname(process.execPath);

function resolveResourcesAppDir(){
  const candidates=[
    path.join(process.resourcesPath||"", "app"),
    path.join(installRoot(), "resources", "app"),
    __dirname
  ];

  for(const p of candidates){
    try{
      if(p && fs.existsSync(path.join(p,"game.html")) &&
         fs.existsSync(path.join(p,"main.js"))){
        return p;
      }
    }catch(e){}
  }

  // Last fallback: the normal portable layout.
  return path.join(installRoot(),"resources","app");
}

const resourcesAppDir = () => resolveResourcesAppDir();
const dataDir = () => path.join(installRoot(), "Data");
const saveFile = () => path.join(dataDir(), "ARALVERSE_Data.json");
const updaterConfigFile = () => path.join(installRoot(), "UpdaterConfig.json");
const updaterLogFile = () => path.join(installRoot(), "UpdaterLastRun.log");

const startupLogFile = () => path.join(installRoot(), "StartupError.log");

function logStartup(text){
  try{
    fs.appendFileSync(
      startupLogFile(),
      `[${new Date().toISOString()}] ${String(text)}\r\n`,
      "utf8"
    );
  }catch(e){}
}

process.on("uncaughtException",error=>{
  logStartup("uncaughtException: "+(error&&error.stack?error.stack:error));
});

process.on("unhandledRejection",error=>{
  logStartup("unhandledRejection: "+(error&&error.stack?error.stack:error));
});


let mainWindow=null;

function logUpdate(text){
  try{
    fs.appendFileSync(
      updaterLogFile(),
      `[${new Date().toISOString()}] ${text}\r\n`,
      "utf8"
    );
  }catch(e){}
}

function ensureDataFolder(){
  fs.mkdirSync(dataDir(),{recursive:true});
}

function readState(){
  ensureDataFolder();
  try{
    const data=JSON.parse(fs.readFileSync(saveFile(),"utf8"));
    return data && typeof data==="object" ? data : {localStorage:{}};
  }catch(e){
    return {version:1,localStorage:{}};
  }
}

function writeState(data){
  ensureDataFolder();
  const target=saveFile();
  const temp=target+".tmp";
  const payload={
    version:1,
    savedAt:new Date().toISOString(),
    localStorage:(data && data.localStorage && typeof data.localStorage==="object")
      ? data.localStorage
      : {}
  };
  fs.writeFileSync(temp,JSON.stringify(payload,null,2),"utf8");
  fs.renameSync(temp,target);
}

function defaultUpdaterConfig(){
  return {manifestUrl:"https://raw.githubusercontent.com/ebaneymar/ARALVERSE/main/update-manifest.json",autoCheck:true,channel:"stable"};
}

function readUpdaterConfig(){
  try{
    const parsed=JSON.parse(fs.readFileSync(updaterConfigFile(),"utf8"));
    return {...defaultUpdaterConfig(),...(parsed&&typeof parsed==="object"?parsed:{})};
  }catch(e){
    return defaultUpdaterConfig();
  }
}

function writeUpdaterConfig(input){
  const cfg=defaultUpdaterConfig();
  if(input && typeof input==="object"){
    cfg.manifestUrl=String(input.manifestUrl||"").trim();
    cfg.autoCheck=input.autoCheck!==false;
    cfg.channel="stable";
  }
  fs.writeFileSync(updaterConfigFile(),JSON.stringify(cfg,null,2),"utf8");
  return cfg;
}

function isAllowedUpdateUrl(raw){
  try{
    const u=new URL(String(raw||"").trim());
    if(u.protocol==="https:")return true;
    if(u.protocol==="http:" && ["localhost","127.0.0.1","::1"].includes(u.hostname))return true;
    return false;
  }catch(e){
    return false;
  }
}

function requestBuffer(url,redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>8)return reject(new Error("Too many redirects."));
    if(!isAllowedUpdateUrl(url))return reject(new Error("Update URL must use HTTPS."));

    const parsed=new URL(url);
    const client=parsed.protocol==="https:"?https:http;

    const req=client.get(parsed,{
      headers:{
        "User-Agent":`ARALVERSE/${APP_VERSION}`,
        "Accept":"application/json, application/octet-stream, */*"
      }
    },res=>{
      const status=Number(res.statusCode||0);

      if([301,302,303,307,308].includes(status) && res.headers.location){
        const next=new URL(res.headers.location,parsed).toString();
        res.resume();
        requestBuffer(next,redirects+1).then(resolve,reject);
        return;
      }

      if(status<200 || status>=300){
        res.resume();
        reject(new Error(`Update server returned HTTP ${status}.`));
        return;
      }

      const chunks=[];
      res.on("data",c=>chunks.push(c));
      res.on("end",()=>resolve(Buffer.concat(chunks)));
    });

    req.setTimeout(30000,()=>req.destroy(new Error("Update request timed out.")));
    req.on("error",reject);
  });
}

function downloadToFile(url,target,onProgress,redirects=0){
  return new Promise((resolve,reject)=>{
    if(redirects>8)return reject(new Error("Too many redirects."));
    if(!isAllowedUpdateUrl(url))return reject(new Error("Download URL must use HTTPS."));

    const parsed=new URL(url);
    const client=parsed.protocol==="https:"?https:http;

    const req=client.get(parsed,{
      headers:{
        "User-Agent":`ARALVERSE/${APP_VERSION}`,
        "Accept":"application/zip, application/octet-stream, */*"
      }
    },res=>{
      const status=Number(res.statusCode||0);

      if([301,302,303,307,308].includes(status) && res.headers.location){
        const next=new URL(res.headers.location,parsed).toString();
        res.resume();
        downloadToFile(next,target,onProgress,redirects+1).then(resolve,reject);
        return;
      }

      if(status<200 || status>=300){
        res.resume();
        reject(new Error(`Update download returned HTTP ${status}.`));
        return;
      }

      const total=Math.max(0,Number(res.headers["content-length"]||0));
      let received=0;
      const file=fs.createWriteStream(target);

      res.on("data",chunk=>{
        received+=chunk.length;
        if(typeof onProgress==="function"){
          onProgress({
            received,total,
            percent:total?Math.min(100,Math.round(received*100/total)):null
          });
        }
      });

      res.pipe(file);
      file.on("finish",()=>file.close(()=>resolve({received,total})));
      file.on("error",err=>{
        try{fs.unlinkSync(target)}catch(e){}
        reject(err);
      });
    });

    req.setTimeout(60000,()=>req.destroy(new Error("Update download timed out.")));
    req.on("error",reject);
  });
}

function semverParts(v){
  return String(v||"0").replace(/^v/i,"").split(/[.-]/).slice(0,3)
    .map(x=>Math.max(0,parseInt(x,10)||0));
}

function compareVersions(a,b){
  const aa=semverParts(a),bb=semverParts(b);
  for(let i=0;i<3;i++){
    const av=aa[i]||0,bv=bb[i]||0;
    if(av>bv)return 1;
    if(av<bv)return -1;
  }
  return 0;
}

function validateManifest(m){
  if(!m||typeof m!=="object")throw new Error("Invalid update manifest.");
  if(String(m.app||"").toLowerCase()!=="aralverse"){
    throw new Error("This update is not for ARALVERSE.");
  }
  if(!String(m.version||"").trim())throw new Error("Manifest has no version.");
  if(!isAllowedUpdateUrl(m.downloadUrl))throw new Error("Manifest download URL must use HTTPS.");
  if(!/^[a-f0-9]{64}$/i.test(String(m.sha256||""))){
    throw new Error("Manifest SHA-256 is missing or invalid.");
  }
  if(String(m.packageType||"app").toLowerCase()!=="app"){
    throw new Error("Only app updates are supported.");
  }

  return {
    app:"ARALVERSE",
    version:String(m.version).trim(),
    published:String(m.published||""),
    downloadUrl:String(m.downloadUrl).trim(),
    sha256:String(m.sha256).toLowerCase(),
    packageType:"app",
    notes:Array.isArray(m.notes)?m.notes.map(x=>String(x)).slice(0,20):[],
    size:Number(m.size||0)||0
  };
}

async function checkForUpdate(){
  const cfg=readUpdaterConfig();

  if(!cfg.manifestUrl){
    return {ok:false,status:"not-configured",currentVersion:APP_VERSION};
  }

  try{
    const buf=await requestBuffer(cfg.manifestUrl);
    const manifest=validateManifest(JSON.parse(buf.toString("utf8")));
    const newer=compareVersions(manifest.version,APP_VERSION)>0;

    return {
      ok:true,
      status:newer?"available":"up-to-date",
      currentVersion:APP_VERSION,
      latestVersion:manifest.version,
      manifest:newer?manifest:null
    };
  }catch(error){
    return {
      ok:false,
      status:"error",
      currentVersion:APP_VERSION,
      error:error&&error.message?error.message:String(error)
    };
  }
}

function sha256File(file){
  return new Promise((resolve,reject)=>{
    const hash=crypto.createHash("sha256");
    const stream=fs.createReadStream(file);
    stream.on("data",d=>hash.update(d));
    stream.on("end",()=>resolve(hash.digest("hex")));
    stream.on("error",reject);
  });
}

function extractZip(zipPath,destination){
  fs.mkdirSync(destination,{recursive:true});

  const scriptPath=path.join(destination,"_extract_update.ps1");
  const script=`param(
[string]$ZipPath,
[string]$Destination
)
$ErrorActionPreference="Stop"
Expand-Archive -LiteralPath $ZipPath -DestinationPath $Destination -Force
`;
  fs.writeFileSync(scriptPath,script,"utf8");

  const result=spawnSync(
    "powershell.exe",
    [
      "-NoLogo",
      "-NoProfile",
      "-ExecutionPolicy","Bypass",
      "-File",scriptPath,
      "-ZipPath",zipPath,
      "-Destination",destination
    ],
    {encoding:"utf8",windowsHide:true,timeout:120000}
  );

  try{fs.unlinkSync(scriptPath)}catch(e){}

  if(result.error)throw result.error;
  if(result.status!==0){
    throw new Error(
      `Could not extract update. ${String(result.stderr||result.stdout||"").trim()}`
    );
  }
}

function verifyInstalledVersion(appDir,expectedVersion){
  const pkgPath=path.join(appDir,"package.json");
  if(!fs.existsSync(pkgPath))throw new Error("Installed package.json is missing.");

  const pkg=JSON.parse(fs.readFileSync(pkgPath,"utf8"));
  if(String(pkg.version)!==String(expectedVersion)){
    throw new Error(
      `Install verification failed. Expected v${expectedVersion}, found v${pkg.version||"unknown"}.`
    );
  }

  const gamePath=path.join(appDir,"game.html");
  if(!fs.existsSync(gamePath))throw new Error("Installed game.html is missing.");

  return true;
}

function copyUpdateIntoRunningApp(sourceDir,targetDir,version){
  const required=["game.html","main.js","preload.js","package.json"];

  for(const name of required){
    if(!fs.existsSync(path.join(sourceDir,name))){
      throw new Error(`Update archive is missing ${name}.`);
    }
  }

  const backupDir=path.join(
    installRoot(),
    "UpdaterBackup",
    `before-${version}-${Date.now()}`
  );
  fs.mkdirSync(backupDir,{recursive:true});

  for(const name of required){
    const current=path.join(targetDir,name);
    if(fs.existsSync(current)){
      fs.copyFileSync(current,path.join(backupDir,name));
    }
  }

  try{
    for(const name of required){
      fs.copyFileSync(path.join(sourceDir,name),path.join(targetDir,name));
      logUpdate(`Copied ${name} into ${targetDir}`);
    }

    verifyInstalledVersion(targetDir,version);
    logUpdate(`Verified installed app version ${version}.`);
    return backupDir;
  }catch(error){
    logUpdate(`Copy/verify failed: ${error.message}. Restoring backup.`);

    for(const name of required){
      const backup=path.join(backupDir,name);
      if(fs.existsSync(backup)){
        try{fs.copyFileSync(backup,path.join(targetDir,name))}catch(e){}
      }
    }
    throw error;
  }
}

async function installUpdate(){
  const checked=await checkForUpdate();

  if(!checked.ok || checked.status!=="available" || !checked.manifest){
    return checked;
  }

  const manifest=checked.manifest;
  const tempRoot=path.join(
    os.tmpdir(),
    `ARALVERSE-Update-${manifest.version}-${Date.now()}`
  );
  const zipPath=path.join(tempRoot,"update.zip");
  const extractDir=path.join(tempRoot,"extracted");

  fs.mkdirSync(tempRoot,{recursive:true});
  logUpdate(`Starting direct-install updater v2 for ${manifest.version}.`);

  try{
    await downloadToFile(manifest.downloadUrl,zipPath,progress=>{
      if(mainWindow && !mainWindow.isDestroyed()){
        mainWindow.webContents.send("mathapang:update-progress",{
          stage:"downloading",
          version:manifest.version,
          ...progress
        });
      }
    });

    if(mainWindow && !mainWindow.isDestroyed()){
      mainWindow.webContents.send("mathapang:update-progress",{
        stage:"verifying",version:manifest.version
      });
    }

    const actual=(await sha256File(zipPath)).toLowerCase();
    if(actual!==manifest.sha256){
      throw new Error("Update verification failed. SHA-256 does not match.");
    }
    logUpdate("SHA-256 verified.");

    if(mainWindow && !mainWindow.isDestroyed()){
      mainWindow.webContents.send("mathapang:update-progress",{
        stage:"installing",version:manifest.version
      });
    }

    extractZip(zipPath,extractDir);
    logUpdate("ZIP extracted.");

    let sourceDir=path.join(extractDir,"app");
    if(!fs.existsSync(path.join(sourceDir,"game.html"))){
      sourceDir=extractDir;
    }

    const targetDir=resourcesAppDir();
    logUpdate(`Resolved live app directory: ${targetDir}`);

    copyUpdateIntoRunningApp(sourceDir,targetDir,manifest.version);

    // Clean temp best-effort after files have already been copied.
    try{fs.rmSync(tempRoot,{recursive:true,force:true})}catch(e){}

    // Relaunch only AFTER the installed files have been verified.
    setTimeout(()=>{
      try{
        app.relaunch();
      }catch(e){
        logUpdate(`app.relaunch error: ${e.message}`);
      }
      app.exit(0);
    },700);

    return {
      ok:true,
      status:"installed-restarting",
      version:manifest.version
    };
  }catch(error){
    logUpdate(`UPDATE ERROR: ${error&&error.stack?error.stack:error}`);
    try{fs.rmSync(tempRoot,{recursive:true,force:true})}catch(e){}

    return {
      ok:false,
      status:"error",
      error:error&&error.message?error.message:String(error)
    };
  }
}

ipcMain.on("mathapang:load-state-sync",(event)=>{
  event.returnValue=readState();
});

ipcMain.on("mathapang:save-state-sync",(event,data)=>{
  try{writeState(data);event.returnValue=true;}
  catch(e){event.returnValue=false;}
});

ipcMain.handle("mathapang:save-state",async(_event,data)=>{
  writeState(data);
  return {ok:true,path:saveFile()};
});

ipcMain.handle("mathapang:open-data-folder",async()=>{
  ensureDataFolder();
  await shell.openPath(dataDir());
  return {ok:true,path:dataDir()};
});

ipcMain.handle("mathapang:updater-info",async()=>{
  const cfg=readUpdaterConfig();
  return {
    version:APP_VERSION,
    config:cfg,
    configured:Boolean(cfg.manifestUrl),
    configPath:updaterConfigFile(),
    engine:"direct-install-v2",
    resolvedAppDir:resourcesAppDir()
  };
});

ipcMain.handle("mathapang:updater-save-config",async(_event,input)=>{
  const url=String(input&&input.manifestUrl||"").trim();
  if(url && !isAllowedUpdateUrl(url)){
    return {ok:false,error:"Update source must be an HTTPS URL."};
  }
  return {
    ok:true,
    config:writeUpdaterConfig({
      manifestUrl:url,
      autoCheck:input&&input.autoCheck!==false
    })
  };
});

ipcMain.handle("mathapang:updater-check",async()=>checkForUpdate());
ipcMain.handle("mathapang:updater-install",async()=>installUpdate());

ipcMain.on("mathapang:exit",()=>app.quit());

function createWindow(){
  try{
    const win=new BrowserWindow({
      width:1366,
      height:768,
      minWidth:960,
      minHeight:600,
      show:true,
      autoHideMenuBar:true,
      backgroundColor:"#38bdf8",
      title:"ARALVERSE",
      icon:path.join(__dirname,"assets","ARALVERSE.ico"),
      webPreferences:{
        preload:path.join(__dirname,"preload.js"),
        contextIsolation:true,
        nodeIntegration:false,
        sandbox:false,
        backgroundThrottling:false
      }
    });

    mainWindow=win;
    try{win.webContents.setAudioMuted(false);}catch(e){}
    win.setMenuBarVisibility(false);

    win.webContents.setWindowOpenHandler(()=>({action:"deny"}));

    win.webContents.on("will-navigate",(event,url)=>{
      if(!String(url||"").startsWith("file:"))event.preventDefault();
    });

    win.webContents.on("did-fail-load",(_event,code,desc,url)=>{
      logStartup(`did-fail-load ${code}: ${desc} ${url||""}`);
    });

    win.webContents.on("render-process-gone",(_event,details)=>{
      logStartup("render-process-gone: "+JSON.stringify(details||{}));
    });

    win.on("unresponsive",()=>{
      logStartup("BrowserWindow became unresponsive.");
    });

    win.on("closed",()=>{
      if(mainWindow===win)mainWindow=null;
    });

    const gameFile=path.join(__dirname,"game.html");

    win.loadFile(gameFile).then(()=>{
      try{win.maximize();}catch(e){}
      logStartup(`Loaded ARALVERSE v${APP_VERSION} successfully.`);
    }).catch(error=>{
      logStartup("loadFile failed: "+(error&&error.stack?error.stack:error));
      try{
        const safe=encodeURIComponent(`
          <html><body style="font-family:Segoe UI;padding:30px">
          <h2>ARALVERSE could not load game.html</h2>
          <p>Please send StartupError.log for repair.</p>
          </body></html>`);
        win.loadURL("data:text/html;charset=utf-8,"+safe);
      }catch(e){}
    });

    return win;
  }catch(error){
    logStartup("createWindow failed: "+(error&&error.stack?error.stack:error));
    throw error;
  }
}

/*
  v1.2.1 deliberately does not use a single-instance lock.
  A stale invisible Electron process could previously cause every new launch
  to quit immediately. Allowing launch here is safer for classroom use.
*/
app.whenReady().then(()=>{
  try{
    ensureDataFolder();

    // Refresh only existing ARALVERSE shortcuts pointing to this installed app.
    if(process.platform==='win32'){
      try{
        const icon=path.join(app.getPath('userData'),'ARALVERSE.ico');
        fs.copyFileSync(path.join(__dirname,'assets','ARALVERSE.ico'),icon);
        const desktop=app.getPath('desktop');
        for(const file of fs.readdirSync(desktop)){
          if(!/^ARALVERSE.*\.lnk$/i.test(file))continue;
          const link=path.join(desktop,file),details=shell.readShortcutLink(link);
          if(path.resolve(details.target).toLowerCase()!==path.resolve(process.execPath).toLowerCase())continue;
          shell.writeShortcutLink(link,'update',{icon,iconIndex:0});
        }
      }catch(error){logStartup('Icon refresh: '+error.message)}
    }
    createWindow();
  }catch(error){
    logStartup("Startup failed: "+(error&&error.stack?error.stack:error));
  }
});

app.on("activate",()=>{
  if(BrowserWindow.getAllWindows().length===0){
    try{createWindow();}catch(error){logStartup(error&&error.stack?error.stack:error)}
  }
});

app.on("window-all-closed",()=>app.quit());
